#!/usr/bin/env python3

import base64
import subprocess
import os

ENCODED_SCRIPT = os.path.join(
    os.path.dirname(__file__),
    "setup.sh"
)

def main():
    with open(ENCODED_SCRIPT, "rb") as f:
        encoded_script = f.read()

    script_in_memory = base64.b64decode(encoded_script)

    subprocess.run(
        ["bash", "-c", script_in_memory.decode("utf-8")],
        check=True
    )

if __name__ == "__main__":
    main()
